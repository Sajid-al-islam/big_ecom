<?php

namespace App\Http\Livewire;

use Livewire\Component;

class QuickViewProduct extends Component
{
    public function render()
    {
        return view('livewire.quick-view-product');
    }
}
