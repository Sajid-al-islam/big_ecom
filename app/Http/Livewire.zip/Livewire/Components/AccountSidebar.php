<?php

namespace App\Http\Livewire\Components;

use Livewire\Component;

class AccountSidebar extends Component
{
    public function render()
    {
        return view('livewire.components.account-sidebar');
    }
}
